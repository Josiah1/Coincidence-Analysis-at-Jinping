#include "Event.h"
#include <iostream>
#include <string>
#include "TChain.h"
using namespace std;

int main(int argc,char** argv)
{
	TString inputfiledir="/work/wangzhe10_work/JinjingLi/work/common-use-JSAP/JSAP/Analysis/TWin/Ostw/ostwoutput/";
        TString outdir;
        Int_t begin,end;
        TChain *tc = new TChain("Event");

        if( argc != 4 ) {
                cout<<"Usage:"<<endl;
                cout<<"    ./accCONFIR inputfile(begin,end) outputdir"<<endl;
                cout<<endl;
                return 1;
        } else {
                begin = atoi(argv[1]);
                end = atoi(argv[2]);
                outdir=argv[3];
                for(Int_t i=begin;i<=end;i++){
                        tc->Add( TString::Format(inputfiledir+"%d.ostw.root",i));
                }
        }


	// For root prompt run
	//ReadoutTreeReader* TR = (ReadoutTreeReader*)TSelector::GetSelector("ReadoutTreeReader.C");
	Event* TR = new Event;

	TR->Init(tc);

	Int_t nEntries = 0;
	//while(!TR->fReader.SetEntry(nEntries))
	while(TR->fReader.Next())
	{
		nEntries++;
	}

	cout<<"Read "<<nEntries<<" entries."<<endl;

}
