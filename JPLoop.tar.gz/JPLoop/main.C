#include "ReadoutTreeReader.h"
#include <iostream>
#include "TChain.h"
using namespace std;

int main()
{
	TChain* tc = new TChain("Readout");
	tc->Add("/home/jinping/JinpingData/Jinping_1ton_Data/01_RawData/run00000331/Jinping_1ton_Phy_20171003_00000331.root");

	// For root prompt run
	//ReadoutTreeReader* TR = (ReadoutTreeReader*)TSelector::GetSelector("ReadoutTreeReader.C");
	ReadoutTreeReader* TR = new ReadoutTreeReader;

	TR->Init(tc);

	Int_t nEntries = 0;
	//while(!TR->fReader.SetEntry(nEntries))
	while(TR->fReader.Next())
	{
		nEntries++;
	}

	cout<<"Read "<<nEntries<<" entries."<<endl;

}
